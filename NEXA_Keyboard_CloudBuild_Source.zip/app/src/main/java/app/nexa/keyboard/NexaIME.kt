package app.nexa.keyboard

import android.annotation.SuppressLint
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class NexaIME : InputMethodService() {
    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreateInputView(): View {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true      // aquí se guardan tus ajustes (tema, tamaños, orden)
        w.setBackgroundColor(0)
        w.isVerticalScrollBarEnabled = false
        w.addJavascriptInterface(Bridge(), "NexaBridge")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) = pushContext()
        }
        val dm = resources.displayMetrics
        val h = minOf(dm.density * 400, dm.heightPixels * 0.55f).toInt()
        w.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
        w.loadUrl("file:///android_asset/nexa.html")
        web = w
        return w
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        pushContext()
    }

    /** Envía al teclado el texto antes del cursor (para mayúscula automática y predicción). */
    private fun pushContext() {
        val before = currentInputConnection?.getTextBeforeCursor(200, 0)?.toString() ?: ""
        web?.evaluateJavascript("window.nexaReset&&nexaReset(" + JSONObject.quote(before) + ")", null)
    }

    inner class Bridge {
        @JavascriptInterface fun commit(t: String) { web?.post { currentInputConnection?.commitText(t, 1) } }
        @JavascriptInterface fun deleteBack(n: Int) { web?.post { currentInputConnection?.deleteSurroundingText(n, 0) } }
        @JavascriptInterface fun enter() {
            web?.post {
                val ic = currentInputConnection ?: return@post
                val o = currentInputEditorInfo?.imeOptions ?: 0
                val action = o and EditorInfo.IME_MASK_ACTION
                if ((o and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
                    action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.performEditorAction(action)
                } else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            }
        }
        @JavascriptInterface fun openSettings() {
            startActivity(Intent(this@NexaIME, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
